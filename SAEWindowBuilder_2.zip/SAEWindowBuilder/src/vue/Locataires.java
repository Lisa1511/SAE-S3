package vue;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Locataires extends  MouseAdapter implements MouseListener, ActionListener{

	private JFrame frame;
	private JTextField txtNom;
	private JTextField txtPrenom;
	private JTextField txtDate;
	private JTextField txtVille;
	private JTextField txtProfession;
	private JTextField textTel;
	private JTextField txtEmail;
	private JTable table;
	JRadioButton radioMonsieur;
	JRadioButton radioMme;
	JRadioButton radioNotPrecised;
	private ButtonGroup btnGroup = new ButtonGroup();
	private ButtonGroup btnGroupStatut = new ButtonGroup();
	private ButtonGroup btnGroupContrat = new ButtonGroup();
	
	JRadioButton radioMarie;
	JRadioButton radioCdi;
	JRadioButton radioCdd;
	JRadioButton radioCelibataire;
	private JTextField txtID;
	final int TAILLE_MAX = 10;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Locataires window = new Locataires();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public Locataires() throws SQLException {
		initialize();
		chargerDonnees();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1100, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel headText = new JLabel("Gestion des Locataires");
		headText.setHorizontalAlignment(SwingConstants.CENTER);
		headText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		headText.setBounds(369, 33, 258, 24);
		frame.getContentPane().add(headText);
		
		JLabel txtCivilite = new JLabel("Civilit\u00E9");
		txtCivilite.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtCivilite.setBounds(57, 94, 60, 13);
		frame.getContentPane().add(txtCivilite);
		
		JLabel lblNewLabel_1 = new JLabel("Nom");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(57, 131, 45, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Pr\u00E9nom");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1_1.setBounds(57, 167, 60, 13);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("Date de Naissance");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2.setBounds(57, 200, 105, 24);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblEmail.setBounds(603, 95, 60, 13);
		frame.getContentPane().add(lblEmail);
		
		JLabel txtStatut = new JLabel("Statut");
		txtStatut.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtStatut.setBounds(603, 132, 60, 13);
		frame.getContentPane().add(txtStatut);
		
		JLabel lblTlphone = new JLabel("T\u00E9l\u00E9phone");
		lblTlphone.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblTlphone.setBounds(603, 168, 60, 13);
		frame.getContentPane().add(lblTlphone);
		
		JLabel lblProfession = new JLabel("Profession");
		lblProfession.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblProfession.setBounds(603, 207, 60, 13);
		frame.getContentPane().add(lblProfession);
		
		JLabel lblNewLabel_2_1 = new JLabel("Ville");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_2_1.setBounds(57, 241, 105, 24);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel txtTypeContrat = new JLabel("Type de Contrat");
		txtTypeContrat.setFont(new Font("Tahoma", Font.PLAIN, 12));
		txtTypeContrat.setBounds(603, 248, 97, 13);
		frame.getContentPane().add(txtTypeContrat);
		Object[][] data = {};
		

		
		
		
		JButton btnAjouter = new JButton("Ajouter");
		btnAjouter.addActionListener(this);
		btnAjouter.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnAjouter.setBounds(64, 306, 85, 21);
		frame.getContentPane().add(btnAjouter);
		
		JButton btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(this);
		btnModifier.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnModifier.setBounds(410, 306, 85, 21);
		frame.getContentPane().add(btnModifier);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.addActionListener(this);
		btnSupprimer.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSupprimer.setBounds(769, 306, 105, 21);
		frame.getContentPane().add(btnSupprimer);
		
		this.radioMonsieur = new JRadioButton("M.");
		radioMonsieur.setBounds(104, 91, 45, 21);
		frame.getContentPane().add(radioMonsieur);
		
		this.radioMme = new JRadioButton("Mme.");
		radioMme.setBounds(165, 91, 60, 21);
		frame.getContentPane().add(radioMme);
		
		this.radioNotPrecised = new JRadioButton("Non Pr\u00E9cis\u00E9");
		radioNotPrecised.setBounds(227, 91, 97, 21);
		frame.getContentPane().add(radioNotPrecised);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 399, 1016, 250);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(this);
		scrollPane.setBounds(10, 10, 1006, 240);
		panel.add(scrollPane);
		
		
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "CIVILITE", "NOM", "PRENOM", "DATE_NAISSANCE", "LIEU", "EMAIL", "STATUT", "TELEPHONE", "PROFESSION", "CONTRAT"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false, false, false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		
		
		scrollPane.setViewportView(table);
		
		txtNom = new JTextField();
		txtNom.setBounds(184, 129, 96, 19);
		frame.getContentPane().add(txtNom);
		txtNom.setColumns(10);
		
		txtPrenom = new JTextField();
		txtPrenom.setColumns(10);
		txtPrenom.setBounds(184, 165, 96, 19);
		frame.getContentPane().add(txtPrenom);
		
		txtDate = new JTextField();
		txtDate.setColumns(10);
		txtDate.setBounds(184, 204, 96, 19);
		frame.getContentPane().add(txtDate);
		
		txtVille = new JTextField();
		txtVille.setColumns(10);
		txtVille.setBounds(184, 245, 96, 19);
		frame.getContentPane().add(txtVille);
		
		txtProfession = new JTextField();
		txtProfession.setColumns(10);
		txtProfession.setBounds(710, 204, 96, 19);
		frame.getContentPane().add(txtProfession);
		
		textTel = new JTextField();
		textTel.setColumns(10);
		textTel.setBounds(710, 165, 96, 19);
		frame.getContentPane().add(textTel);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(710, 92, 96, 19);
		frame.getContentPane().add(txtEmail);
		
		this.radioMarie = new JRadioButton("Mari\u00E9(e)");
		radioMarie.setBounds(709, 128, 74, 21);
		frame.getContentPane().add(radioMarie);
		
		this.radioCelibataire = new JRadioButton("C\u00E9libataire");
		radioCelibataire.setBounds(804, 128, 97, 21);
		frame.getContentPane().add(radioCelibataire);
		
		this.radioCdi = new JRadioButton("CDI");
		radioCdi.setBounds(706, 244, 74, 21);
		frame.getContentPane().add(radioCdi);
		
		this.radioCdd = new JRadioButton("CDD");
		radioCdd.setBounds(804, 244, 97, 21);
		frame.getContentPane().add(radioCdd);
		
		this.btnGroup.add(radioMonsieur);
		this.btnGroup.add(radioMme);
		this.btnGroup.add(radioNotPrecised);
		
		this.btnGroupContrat.add(radioCdd);
		this.btnGroupContrat.add(radioCdi);
		
		this.btnGroupStatut.add(radioCelibataire);
		this.btnGroupStatut.add(radioMarie);
		
		txtID = new JTextField();
		txtID.setBounds(184, 66, 96, 19);
		frame.getContentPane().add(txtID);
		txtID.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(57, 69, 45, 13);
		frame.getContentPane().add(lblNewLabel);
		
		table.addMouseListener(new MouseAdapter() {
		    public void mouseClicked(MouseEvent e) {
		    	DefaultTableModel dModel = (DefaultTableModel)table.getModel();
				int index = table.getSelectedRow();
				txtID.setText(dModel.getValueAt(index, 0).toString());
				switch(dModel.getValueAt(index, 1).toString()) {
				case "M.":
					radioMonsieur.setSelected(true);
					break;
				case "Mme.":
					radioMme.setSelected(true);
					break;
				case "Non pr�cis�":
					radioNotPrecised.setSelected(true);
				}
				txtNom.setText(dModel.getValueAt(index, 2).toString());
				txtPrenom.setText(dModel.getValueAt(index, 3).toString());
				txtDate.setText(dModel.getValueAt(index, 4).toString());
				txtDate.setText(txtDate.getText().substring(0, TAILLE_MAX));
				txtVille.setText(dModel.getValueAt(index, 5).toString());
				txtEmail.setText(dModel.getValueAt(index, 6).toString());
				switch(dModel.getValueAt(index, 7).toString()) {
				case "Mari�(e)":
					radioMarie.setSelected(true);
					break;
				case"C�libataire":
					radioCelibataire.setSelected(true);
					break;
				}
				textTel.setText(dModel.getValueAt(index, 8).toString());
				txtProfession.setText(dModel.getValueAt(index,9).toString());
				switch(dModel.getValueAt(index, 10).toString()) {
				case "CDI":
					radioCdi.setSelected(true);
					break;
				case "CDD":
					radioCdd.setSelected(true);
					break;
				}
		      }
		});
	}
	private void chargerDonnees() throws SQLException{
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		
		String sql = "SELECT * FROM SAE_LOCATAIRE ORDER BY ID";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			PreparedStatement pst;
			pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();
			ResultSetMetaData rsm = res.getMetaData();
			int c = rsm.getColumnCount();
			model.setRowCount(c);
			while(res.next()) {
				Vector v = new Vector();
				for(int i=0; i<=c;i++) {
					v.add(res.getString(1));
					v.add(res.getString(2));
					v.add(res.getString(3));
					v.add(res.getString(4));
					v.add(res.getString(5));
					v.add(res.getString(6));
					v.add(res.getString(7));
					v.add(res.getString(8));
					v.add(res.getString(9));
					v.add(res.getString(10));
					v.add(res.getString(11));
				}
				model.addRow(v);
				
				
				
				
				
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(frame, e);;
		}
	}
	public void actionPerformed(ActionEvent e) {
		JButton button = (JButton)e.getSource();
		int id = Integer.valueOf(this.txtID.getText());
		String civilite="";
		String nom =this.txtNom.getText();
		String prenom=this.txtPrenom.getText();
		String DateNaissance = this.txtDate.getText();
		String ville = this.txtVille.getText();
		String email = this.txtEmail.getText();
		String statut = "";
		String telephone = this.textTel.getText();
		String profession = this.txtProfession.getText();
		String typeContrat = "";
		switch(button.getText()) {
		case "Ajouter":
			if(this.radioMonsieur.isSelected()) {
				civilite = this.radioMonsieur.getText();
			}
			if(this.radioMme.isSelected()) {
				civilite = this.radioMme.getText();
			}
			if(this.radioNotPrecised.isSelected()) {
				civilite = this.radioNotPrecised.getText();
			}
			
			if(this.radioCdd.isSelected()) {
				typeContrat = this.radioCdd.getText();
			}
			if(this.radioCdi.isSelected()) {
				typeContrat = this.radioCdi.getText();
			}
			
			if(this.radioMarie.isSelected()) {
				statut = this.radioMarie.getText();
			}
			if(this.radioCelibataire.isSelected()) {
				statut = this.radioCelibataire.getText();
			}
			
			ajouterUnLocataire(id,civilite,nom,prenom,DateNaissance,ville,email, statut, telephone, profession, typeContrat);
			JOptionPane.showMessageDialog(frame, "Le Locataire "+nom+" "+prenom+" a bien �t� ajout� ! ");
			try {
				chargerDonnees();
			} catch (SQLException e2) {
				
				e2.printStackTrace();
			}

			break;
			
		case "Modifier":
			if(this.radioMonsieur.isSelected()) {
				civilite = this.radioMonsieur.getText();
			}
			if(this.radioMme.isSelected()) {
				civilite = this.radioMme.getText();
			}
			if(this.radioNotPrecised.isSelected()) {
				civilite = this.radioNotPrecised.getText();
			}
			
			if(this.radioCdd.isSelected()) {
				typeContrat = this.radioCdd.getText();
			}
			if(this.radioCdi.isSelected()) {
				typeContrat = this.radioCdi.getText();
			}
			
			if(this.radioMarie.isSelected()) {
				statut = this.radioMarie.getText();
			}
			if(this.radioCelibataire.isSelected()) {
				statut = this.radioCelibataire.getText();
			}
			try {
				
				modifierLocataire(id,civilite,nom,prenom,DateNaissance,ville,email, statut, telephone, profession, typeContrat);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			JOptionPane.showMessageDialog(frame, "Modifications enregistr�es ! ");
			try {
				chargerDonnees();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			break;
		case "Supprimer":
			try {
				supprimerLocataire(id);
			}catch(Exception exp) {
				exp.printStackTrace();
			}
			JOptionPane.showMessageDialog(frame, "Suppression confirm�e ! ");
			try {
				chargerDonnees();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		
			
		}
		
	}
	public void ajouterUnLocataire(int id,String civilite, String nom, String prenom, String DateNaissance, String ville, String email, String statut, String telephone, String profession, String typeContrat) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			CallableStatement stmt = con.prepareCall("{call INSERTION_LOCATAIRE(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.setInt(1, id);
			stmt.setString(2, civilite);
			stmt.setString(3, nom);
			stmt.setString(4, prenom);
			stmt.setString(5, DateNaissance);
			stmt.setString(6, ville);
			stmt.setString(7, email);
			stmt.setString(8, statut);
			stmt.setString(9, telephone);
			stmt.setString(10, profession);
			stmt.setString(11, typeContrat);
			stmt.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void modifierLocataire(int id,String civilite, String nom, String prenom, String DateNaissance, String ville, String email, String statut, String telephone, String profession, String typeContrat) 
			throws SQLException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			CallableStatement stmt = con.prepareCall("{call MODIFIER_LOCATAIRE(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.setInt(1, id);
			stmt.setString(2, civilite);
			stmt.setString(3, nom);
			stmt.setString(4, prenom);
			stmt.setString(5, DateNaissance);
			stmt.setString(6, ville);
			stmt.setString(7, email);
			stmt.setString(8, statut);
			stmt.setString(9, telephone);
			stmt.setString(10, profession);
			stmt.setString(11, typeContrat);
			stmt.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	public void supprimerLocataire(int id) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			CallableStatement stmt = con.prepareCall("{call SUPPRIMER_LOCATAIRE(?)}");
			stmt.setInt(1, id);
			stmt.execute();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void mouseClicked(MouseEvent e) {
	}

	
	@Override
	public void mousePressed(MouseEvent e) {
		
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
