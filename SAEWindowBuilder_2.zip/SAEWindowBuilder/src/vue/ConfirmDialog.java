package vue;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConfirmDialog implements ActionListener {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConfirmDialog window = new ConfirmDialog();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ConfirmDialog() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(200, 200, 350, 250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		
		JLabel text = new JLabel("Les donn�es ont bien �t� enregistr�es !");
		text.setBounds(10, 83, 316, 25);
		frame.getContentPane().add(text);

		JButton login = new JButton("Connectez-vous maintenant");
		login.addActionListener(this);
		login.setBounds(53, 156, 214, 47);
		frame.getContentPane().setLayout(null);
		text.setHorizontalAlignment(SwingConstants.CENTER);
		text.setFont(new Font("Tahoma", Font.PLAIN, 16));
	
		frame.getContentPane().add(login);
		
		JLabel lblNewLabel = new JLabel("New label");
		
		
	}
	public void actionPerformed(ActionEvent e) {
		Connexion connexion = new Connexion();
		connexion.main(null);
		this.frame.dispose();
	}
}
