package vue;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.SwingConstants;
import javax.swing.JFileChooser;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Logements implements ActionListener {

	private JFrame frame;
	private JTable table;
	private JTextField txtID;
	private JTextField txtBatiment;
	private JTextField txtYear;
	private JTextField txtNumber;
	private JTextField txtPieces;
	private JTextField txtSurface;
	private JTextField txtAdresse;
	private JTextField txtVille;
	private JTextField txtCodePostal;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Logements window = new Logements();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 */
	public Logements() throws SQLException {
		initialize();
		chargerDonnees();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1042, 715);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Gestion des Logements");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(293, 20, 259, 33);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nom du Batiment");
		lblNewLabel_1.setBounds(34, 106, 100, 13);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Ann\u00E9e de Construction");
		lblNewLabel_1_1.setBounds(34, 137, 147, 13);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("ID");
		lblNewLabel_1_2.setBounds(34, 83, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Num\u00E9ro du Logement");
		lblNewLabel_1_3.setBounds(34, 167, 129, 13);
		frame.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Nombre de Pi\u00E8ces");
		lblNewLabel_1_4.setBounds(34, 200, 129, 13);
		frame.getContentPane().add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Surface");
		lblNewLabel_1_5.setBounds(34, 237, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Adresse");
		lblNewLabel_1_6.setBounds(554, 83, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_7 = new JLabel("Ville");
		lblNewLabel_1_7.setBounds(554, 106, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_7);
		
		JLabel lblNewLabel_1_8 = new JLabel("Code Postal");
		lblNewLabel_1_8.setBounds(554, 137, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_8);
		
		JLabel lblNewLabel_1_8_1 = new JLabel("Balcon");
		lblNewLabel_1_8_1.setBounds(554, 177, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_8_1);
		
		JLabel lblNewLabel_1_8_2 = new JLabel("Garage");
		lblNewLabel_1_8_2.setBounds(554, 203, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_8_2);
		
		JLabel lblNewLabel_1_8_3 = new JLabel("Description");
		lblNewLabel_1_8_3.setBounds(554, 251, 88, 13);
		frame.getContentPane().add(lblNewLabel_1_8_3);
		
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(this);
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton.setBounds(78, 290, 85, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnModifier = new JButton("Modifier");
		btnModifier.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnModifier.setBounds(408, 290, 85, 21);
		frame.getContentPane().add(btnModifier);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnSupprimer.setBounds(729, 290, 100, 21);
		frame.getContentPane().add(btnSupprimer);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 350, 1008, 318);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"ID", "Nom du Batiment", "Ann\u00E9e de Construction", "N\u00B0 Logement", "Nombre de Pi\u00E8ces", "Surface en m�", "Adresse", "Ville", "Code Postal", "Balcon", "Garage", "Description"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(35);
		table.getColumnModel().getColumn(1).setPreferredWidth(95);
		table.getColumnModel().getColumn(2).setPreferredWidth(121);
		table.getColumnModel().getColumn(4).setPreferredWidth(102);
		scrollPane.setViewportView(table);
		
		txtID = new JTextField();
		txtID.setBounds(171, 80, 96, 19);
		frame.getContentPane().add(txtID);
		txtID.setColumns(10);
		
		txtBatiment = new JTextField();
		txtBatiment.setColumns(10);
		txtBatiment.setBounds(171, 103, 96, 19);
		frame.getContentPane().add(txtBatiment);
		
		txtYear = new JTextField();
		txtYear.setColumns(10);
		txtYear.setBounds(171, 134, 96, 19);
		frame.getContentPane().add(txtYear);
		
		txtNumber = new JTextField();
		txtNumber.setColumns(10);
		txtNumber.setBounds(171, 164, 96, 19);
		frame.getContentPane().add(txtNumber);
		
		txtPieces = new JTextField();
		txtPieces.setColumns(10);
		txtPieces.setBounds(173, 197, 96, 19);
		frame.getContentPane().add(txtPieces);
		
		txtSurface = new JTextField();
		txtSurface.setColumns(10);
		txtSurface.setBounds(171, 226, 96, 19);
		frame.getContentPane().add(txtSurface);
		
		txtAdresse = new JTextField();
		txtAdresse.setColumns(10);
		txtAdresse.setBounds(652, 80, 96, 19);
		frame.getContentPane().add(txtAdresse);
		
		txtVille = new JTextField();
		txtVille.setColumns(10);
		txtVille.setBounds(652, 105, 96, 19);
		frame.getContentPane().add(txtVille);
		
		txtCodePostal = new JTextField();
		txtCodePostal.setColumns(10);
		txtCodePostal.setBounds(654, 134, 96, 19);
		frame.getContentPane().add(txtCodePostal);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(634, 237, 249, 41);
		frame.getContentPane().add(textField);
		
		JRadioButton radioOuiBal = new JRadioButton("Oui");
		radioOuiBal.setBounds(616, 173, 54, 21);
		frame.getContentPane().add(radioOuiBal);
		
		JRadioButton radioOuiGar = new JRadioButton("Oui");
		radioOuiGar.setBounds(616, 196, 54, 21);
		frame.getContentPane().add(radioOuiGar);
		
		JRadioButton radioNonBal = new JRadioButton("Non");
		radioNonBal.setBounds(696, 173, 54, 21);
		frame.getContentPane().add(radioNonBal);
		
		JRadioButton radioNonGar = new JRadioButton("Non");
		radioNonGar.setBounds(696, 196, 54, 21);
		frame.getContentPane().add(radioNonGar);
	}
	private void chargerDonnees() throws SQLException{
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		
		String sql = "SELECT * FROM SAE_LOGEMENT ORDER BY ID_LOGEMENT";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			PreparedStatement pst;
			pst = con.prepareStatement(sql);
			ResultSet res = pst.executeQuery();
			ResultSetMetaData rsm = res.getMetaData();
			int c = rsm.getColumnCount();
			model.setRowCount(c);
			while(res.next()) {
				Vector v = new Vector();
				for(int i=0; i<=c;i++) {
					v.add(res.getString(6));
					v.add(res.getString(7));
					v.add(res.getString(11));
					v.add(res.getString(12));
					v.add(res.getString(1));
					v.add(res.getString(2));
					v.add(res.getString(8));
					v.add(res.getString(10));
					v.add(res.getString(9));//codepostal
					if(res.getString(4).equals("O")) {
						v.add("Oui");
					}else {
						v.add("Non");
					}
					
					if(res.getString(5).equals("O")){
						v.add("Oui");
					}else {
						v.add("Non");
					}
					v.add(res.getString(3));
				}
				model.addRow(v);
				
				
				
				
				
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(frame, e);;
		}
	}
	public void actionPerformed(ActionEvent e) {
		JButton button = (JButton) e.getSource();
		switch(button.getText()) {
		case "Ajouter":
			
		}
	}
	public void ajouterLogement(int id,String batiment, String anneeConstruction, String numeroLogement, int nbPieces, Double surface, String adresse, String ville, String codePostal, char Balcon, char Garage, String description) {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			String query = "INSERT INTO SAE_LOGEMENT(NB_PIECE,SURFACE_HAB,DESCRIPTION_LOGEMENT,BALCON,GARAGE,ID_LOGEMENT,BATIMENT,ADRESSE,"
					+ "CODEPOSTAL,VILLE,ANNEECONSTRUCTION,NUMLOGEMENT) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setInt(1, nbPieces);
			stmt.setString(Garage, query);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
