package vue;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Connexion implements ActionListener {

	private JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;
	JLabel emailText = new JLabel("Votre email : ");
	JLabel passwordText = new JLabel("Votre mot de passe : ");
	public static  boolean estConnecte = false;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Connexion window = new Connexion();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Connexion() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel welcometext = new JLabel("Bienvenue");
		welcometext.setHorizontalAlignment(SwingConstants.CENTER);
		welcometext.setFont(new Font("Tahoma", Font.PLAIN, 16));
		welcometext.setBounds(118, 20, 189, 25);
		frame.getContentPane().add(welcometext);
		
		JLabel lblConnectezvousPourAccder = new JLabel("Connectez-vous pour acc\u00E9der \u00E0 votre tableau de bord");
		lblConnectezvousPourAccder.setHorizontalAlignment(SwingConstants.CENTER);
		lblConnectezvousPourAccder.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblConnectezvousPourAccder.setBounds(10, 68, 399, 36);
		frame.getContentPane().add(lblConnectezvousPourAccder);
		
		
		emailText.setFont(new Font("Tahoma", Font.PLAIN, 14));
		emailText.setBounds(37, 122, 115, 25);
		frame.getContentPane().add(emailText);
		
		
		passwordText.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passwordText.setBounds(37, 173, 138, 25);
		frame.getContentPane().add(passwordText);
		
		JButton loginBtn = new JButton("Connexion");
		loginBtn.addActionListener(this);
		loginBtn.setFont(new Font("Tahoma", Font.PLAIN, 14));
		loginBtn.setBounds(147, 221, 123, 32);
		frame.getContentPane().add(loginBtn);
		
		textField = new JTextField();
		textField.setBounds(198, 122, 171, 25);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(198, 175, 171, 25);
		frame.getContentPane().add(passwordField);
	}
	public void actionPerformed(ActionEvent e) {
		String email = textField.getText();
		char[] password = passwordField.getPassword();
		String userPassword=new String(password);
		if(email.length()==0 || userPassword.length()==0) {
			JDialog empty = new JDialog();
			 empty.setBounds(200, 200, 350, 150);
			 JLabel text = new JLabel("Erreur : Il y'a des champs vides !!!");
			 empty.getContentPane().add(text);
			 empty.setVisible(true);
		}else {
			Connection con = null;
			String query = "SELECT * FROM SAE_PROPRIETAIRE WHERE email=?";
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
				PreparedStatement stmt = con.prepareStatement(query);
				stmt.setString(1, email);
				ResultSet res = stmt.executeQuery();
				String storedPassword = "";
				while(res.next()) {
					storedPassword = res.getString("password");
				}
				
				if(storedPassword.equals(userPassword)) {
				JOptionPane.showMessageDialog(null, "Connect� !");
				int i = JOptionPane.OK_OPTION;
					
				}else {
					JOptionPane.showMessageDialog(null,"Identifiants invalides");
				}
				
			}catch(ClassNotFoundException | SQLException e1){
				e1.printStackTrace();
			}
		}
		
	}
}
