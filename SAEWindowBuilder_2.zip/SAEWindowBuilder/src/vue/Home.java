package vue;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.sound.midi.MidiDevice.Info;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home implements ActionListener {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JPasswordField passwordField_1;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws Exception {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home window = new Home();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	    
	}

	/**
	 * Create the application.
	 */
	public Home() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 586, 331);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel welcomeTxt = new JLabel("Bienvenue");
		welcomeTxt.setHorizontalAlignment(SwingConstants.CENTER);
		welcomeTxt.setFont(new Font("Tahoma", Font.PLAIN, 16));
		welcomeTxt.setBounds(173, 26, 204, 32);
		frame.getContentPane().add(welcomeTxt);
		
		JLabel welcomeSubTxt = new JLabel("D\u00E9finissez vos identifiants pour continuer");
		welcomeSubTxt.setHorizontalAlignment(SwingConstants.CENTER);
		welcomeSubTxt.setFont(new Font("Tahoma", Font.PLAIN, 14));
		welcomeSubTxt.setBounds(118, 69, 320, 32);
		frame.getContentPane().add(welcomeSubTxt);
		
		JLabel nameField = new JLabel("Votre nom : ");
		nameField.setHorizontalAlignment(SwingConstants.CENTER);
		nameField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		nameField.setBounds(67, 131, 99, 24);
		frame.getContentPane().add(nameField);
		
		JLabel emailField = new JLabel("Votre email : ");
		emailField.setHorizontalAlignment(SwingConstants.CENTER);
		emailField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		emailField.setBounds(67, 176, 99, 24);
		frame.getContentPane().add(emailField);
		
		JLabel passwordField = new JLabel("Choisissez un mot de passe : ");
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 14));
		passwordField.setBounds(77, 214, 194, 32);
		frame.getContentPane().add(passwordField);
		
		textField = new JTextField();
		textField.setBounds(295, 131, 161, 24);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(295, 176, 161, 24);
		frame.getContentPane().add(textField_1);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(295, 214, 161, 24);
		frame.getContentPane().add(passwordField_1);
		
		JButton btnEnregistrer = new JButton("Enregistrer");
		btnEnregistrer.addActionListener(this);
		btnEnregistrer.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnEnregistrer.setBounds(222, 263, 107, 21);
		frame.getContentPane().add(btnEnregistrer);
	}
	public void actionPerformed(ActionEvent e) {
		String nom = textField.getText();
		String email = textField_1.getText();
		char[] password = passwordField_1.getPassword();
		String userPassword = new String(password);

		
		
		 Connection con = null;
		 String query = "INSERT INTO SAE_PROPRIETAIRE(name,email,password) VALUES(?,?,?)";
		 if(nom.length() == 0 || email.length() == 0 || userPassword.length()== 0) {
			 JDialog empty = new JDialog();
			 empty.setBounds(200, 200, 350, 150);
			 JLabel text = new JLabel("Erreur : Il y'a des champs vides !!!");
			 empty.add(text);
			 empty.setVisible(true);
		 }else {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@telline.univ-tlse3.fr:1521:etupre","NGD4387A","303108");
			PreparedStatement stmt = con.prepareStatement(query);
			stmt.setString(1, nom);
			stmt.setString(2, email);
			stmt.setString(3, userPassword);
			stmt.executeUpdate();
			
			ConfirmDialog dialog = new ConfirmDialog();
			dialog.main(null);
			this.frame.dispose();

		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		}
		
	   
	}
}
