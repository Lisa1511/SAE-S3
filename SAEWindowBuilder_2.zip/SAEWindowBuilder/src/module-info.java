module SAEWindowBuilder {
	requires java.desktop;
	requires java.sql;
}